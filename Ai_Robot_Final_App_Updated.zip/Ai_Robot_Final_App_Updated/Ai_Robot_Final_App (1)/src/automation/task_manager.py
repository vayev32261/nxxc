
class Task:
    def __init__(self, name, action, condition=None):
        self.name = name
        self.action = action
        self.condition = condition

    def run(self, context):
        if self.condition is None or self.condition(context):
            self.action(context)

class TaskOrchestrator:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append(task)

    def run(self, context):
        for task in self.tasks:
            task.run(context)

# Example Usage:
def send_message(context):
    print("Sending message:", context["message"])

def check_message_length(context):
    return len(context["message"]) > 10

if __name__ == "__main__":
    orchestrator = TaskOrchestrator()
    
    # Define tasks with conditions
    task1 = Task("Check Length", send_message, condition=check_message_length)
    
    # Add tasks to orchestrator
    orchestrator.add_task(task1)
    
    # Run orchestration
    orchestrator.run({"message": "Hello, this is a test message."})
