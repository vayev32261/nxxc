from flask import Flask, render_template, request, jsonify
from src.nlp.model import AutonomousAI
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, TimeoutError
import time

app = Flask(__name__, template_folder='templates')

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Create a ThreadPoolExecutor
executor = ThreadPoolExecutor(max_workers=1)

# Initialize the AutonomousAI
ai = AutonomousAI()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("user_input")

    if not user_input:
        app.logger.warning("No input provided")
        return jsonify({"response": "Error: No input provided", "status": "error"})

    future = executor.submit(ai.generate_and_execute_solution, user_input)
    try:
        response = future.result(timeout=120)  # 120 seconds timeout
        app.logger.info(f"Generated response: {response}")
        return jsonify({"response": response, "status": "success"})
    except TimeoutError:
        app.logger.error("Task execution timed out")
        return jsonify({"response": "Error: Task execution timed out", "status": "error"})
    except Exception as e:
        app.logger.error(f"An error occurred: {str(e)}")
        app.logger.error(traceback.format_exc())
        return jsonify({"response": f"Error: {str(e)}", "status": "error"})

@app.route("/modify", methods=["POST"])
def modify_ai():
    new_code = request.json.get("new_code")

    if not new_code:
        app.logger.warning("No code provided")
        return jsonify({"response": "Error: No code provided", "status": "error"})

    try:
        ai.modify_self(new_code)
        return jsonify({"response": "AI has been modified and restarted", "status": "success"})
    except Exception as e:
        app.logger.error(f"An error occurred during self-modification: {str(e)}")
        app.logger.error(traceback.format_exc())
        return jsonify({"response": f"Error during self-modification: {str(e)}", "status": "error"})

if __name__ == "__main__":
    app.run(debug=True)