#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request
from src.nlp.model import generate_response

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("user_input")
    response = generate_response(user_input)
    return {"response": response}

if __name__ == "__main__":
    app.run(debug=True)
