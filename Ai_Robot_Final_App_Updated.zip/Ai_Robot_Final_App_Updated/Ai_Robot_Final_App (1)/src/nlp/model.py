
from transformers import pipeline

def chat_with_ai(input_text):
    chatbot = pipeline("conversational", model="microsoft/DialoGPT-medium")
    response = chatbot(input_text)
    return response

if __name__ == "__main__":
    print("Welcome to AI Chatbot. Type 'exit' to end.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == 'exit':
            break
        response = chat_with_ai(user_input)
        print("AI:", response[0]["generated_text"])
