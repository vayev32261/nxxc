from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import openai
import logging

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Set up your OpenAI API key
openai.api_key = "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"

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/run-task', methods=['POST'])
async def run_task():
    try:
        data = request.json
        message = data.get('message', '')
        response = await handle_task(message)
        return jsonify({"status": "success", "response": response})
    except Exception as e:
        logging.error(f"Error in /api/run-task: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/solve-prioritized', methods=['POST'])
async def solve_prioritized():
    try:
        data = request.json
        problem = data.get('problem', '')
        priority = data.get('priority', 5)
        solution = await solve_prioritized_task(problem, priority)
        return jsonify({"status": "success", "solution": solution})
    except Exception as e:
        logging.error(f"Error in /api/solve-prioritized: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

async def handle_task(message):
    try:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo",
            prompt=message,
            max_tokens=50
        )
        return response.choices[0].text.strip()
    except Exception as e:
        raise RuntimeError(f"Failed to handle task: {str(e)}")

async def solve_prioritized_task(problem, priority):
    try:
        # Business logic for solving prioritized tasks
        return f"Prioritized problem-solving (Priority {priority}) for: {problem}"
    except Exception as e:
        raise RuntimeError(f"Failed to solve prioritized task: {str(e)}")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3001, debug=True)
