import os
import shutil

# Define the paths
project_root = os.path.dirname(os.path.abspath(__file__))  # Current directory where server.py is located
src_templates_dir = os.path.join(project_root, 'src', 'ui', 'templates')
target_templates_dir = os.path.join(project_root, 'templates')

# Ensure the target templates directory exists
os.makedirs(target_templates_dir, exist_ok=True)

# Move index.html to the correct location
index_html_path = os.path.join(src_templates_dir, 'index.html')
target_index_html_path = os.path.join(target_templates_dir, 'index.html')

# Check if the file exists in the src/ui/templates/ directory
if os.path.exists(index_html_path):
    shutil.move(index_html_path, target_index_html_path)
    print(f"Moved {index_html_path} to {target_index_html_path}")
else:
    print(f"File not found: {index_html_path}. Please check the directory structure.")

print("Directory structure fixed. You can now run the server.")
